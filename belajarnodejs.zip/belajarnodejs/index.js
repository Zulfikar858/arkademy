// const tambah = require('./function')

// console.log(tambah.fungsiTambah(22,2))